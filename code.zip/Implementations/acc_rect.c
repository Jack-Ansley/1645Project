#include <stdio.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>

#define		NSTEPS	8388600
#define		NITER 	8388600
#define		P_START	0 
#define		P_END	10 


struct timeval startTime;
struct timeval finishTime;
double timeIntervalLength;

double h;

double area = 0.0;

int main(int argc, char* argv[])
{
	int i;
	h = (double)(P_END-P_START)/NSTEPS;
//----------------------------------------------------------------------------------------------
	//Get the start time
	gettimeofday(&startTime, NULL);

    // Change num_gangs() to vary the number of threads. There is no need to implement critical section here. It seems to be done automatically (for cariable area).
    // Apparently num_gangs(1) vector_length(1) is supposed to execute this code serially. But seems to be quicker than the serical execution. (ser_rect)
    # pragma acc parallel loop num_gangs(1) //vector_length(1)// num_workers(0)
	for(i = 0; i < NITER; i++)
	{
        area += h*cos(i*h);
	}
	//Get the end time
	gettimeofday(&finishTime, NULL);  /* after time */
//-----------------------------------------------------------------------------------------------
	
	printf("Result : %.2lf \n",area);
	
	//Calculate the interval length 
	timeIntervalLength = (double)(finishTime.tv_sec-startTime.tv_sec) * 1000000 
		     + (double)(finishTime.tv_usec-startTime.tv_usec);
	timeIntervalLength=timeIntervalLength/1000;

	//Print the interval lenght
	printf("Interval length: %g msec.\n", timeIntervalLength);

        
	return 0;
}
